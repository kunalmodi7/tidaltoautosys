package com.tidal.autosys;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		List<String> l1 = new ArrayList<>(Arrays.asList("Amit", "Kumar", "16", "Bangalore"));
		List<String> l2 = new ArrayList<>(Arrays.asList("Amit", "Kumar", "36", "Bangalore"));
		
		System.out.println("Rows are equal? " + l1.equals(l2));
	}

}
