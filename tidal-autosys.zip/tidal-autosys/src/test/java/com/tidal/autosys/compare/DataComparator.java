package com.tidal.autosys.compare;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import com.tidal.autosys.utils.DBUtility;

public class DataComparator {

	public void dataCompare(String query1, String query2) throws SQLException {
		SortedSet<List<String>> dbData1 = getData(query1);
		SortedSet<List<String>> dbData2 = getData(query2);
		
		boolean areListsEqual = equals(dbData1, dbData2);
		
		if (areListsEqual) {
			System.out.println("Data are same");
		} else {
			System.out.println("Data are different");
		}
		
	}
	
	private static boolean equals(SortedSet<List<String>> dbData1, SortedSet<List<String>> dbData2) {
		// You can convert list into set so that the data is sorted and index comparison provides correct result 
		
		if (dbData1.size() != dbData2.size()) {
			System.out.println("List size doesn't match");
			return false;
		}
		
		Iterator<List<String>> it1 = dbData1.iterator();
		Iterator<List<String>> it2 = dbData2.iterator();
		
		while (it1.hasNext() && it2.hasNext()) {
			List<String> data1 = it1.next();
			List<String> data2 = it2.next();
			
			// compare primary key
//			if (!data1.get(0).equals(data2.get(0))) {
//				return false;
//			}
			
			// compare all columns
			return data1.equals(data2);
		}
		return true;
	}

	private SortedSet<List<String>> getData(String query) throws SQLException {

		ResultSet rs = DBUtility.dbConnection(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		int columnCount = rsmd.getColumnCount();

		SortedSet<List<String>> result = new TreeSet<>();

		// While Loop to iterate through all data and print results
		while (rs.next()) {
			List<String> row = new ArrayList<>();
			int i = 1;
			while (i <= columnCount) {
				row.add(rs.getString(i++));
			}
			result.add(row);
		}

		return result;

	}
}
