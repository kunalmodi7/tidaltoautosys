package com.tidal.autosys.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBUtility {

	public static ResultSet dbConnection(String query) throws SQLException {
		Connection con = null;
		
		ResultSet rs = null;
		
		try {
			// Connection URL Syntax: "jdbc:mysql://ipaddress:portnumber/db_name"
			String dbUrl = "jdbc:mysql://localhost:3036/emp";

			// Database Username
			String username = "root";

			// Database Password
			String password = "guru99";

			// Load mysql jdbc driver
			Class.forName("com.mysql.jdbc.Driver");

			// Create Connection to DB
			con = DriverManager.getConnection(dbUrl, username, password);

			// Create Statement Object
			Statement stmt = con.createStatement();

			// Execute the SQL Query. Store results in ResultSet
			rs = stmt.executeQuery(query);
	
		} catch (Exception e) {
			return null;
		} finally {
			// closing DB Connection
			if (null != con)
				con.close();
		}
		
		return rs;
	

	}

}
